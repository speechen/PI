# MobileFeinstaub App

Die App MobileFeinstaub für Android erlaubt es, einen SDS011 Sensor mit einem Usb2serial Adapter per USB [OTG](https://de.wikipedia.org/wiki/Universal_Serial_Bus#USB_On-the-go)-Kabel direkt am Smartphone zu betreiben.

