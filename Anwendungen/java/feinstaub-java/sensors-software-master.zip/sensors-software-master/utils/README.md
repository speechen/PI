# Utils

Here are some utils, which may be used to do tasks around the fine dust sensor project.

## External utils

[Stress Test Scripts for MQTT using Python and Ansible](https://github.com/bluewindthings/mqtt-stress)

