This dataset is part of the Open Data Initiative datasets of LGL,

https://www.lgl-bw.de/lgl-internet/opencms/de/07_Produkte_und_Dienstleistungen/Open_Data_Initiative/index.html

Copyright/License: CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/deed.de) 
Datenquelle: LGL, www.lgl-bw.de

[Gemeinden (ZIP-Archiv mit SHAPE-Dateien, Stand 30.06.2015) (ZIP, 7.616 KB)](https://www.lgl-bw.de/lgl-internet/web/sites/default/de/07_Produkte_und_Dienstleistungen/Open_Data_Initiative/Galerien/Dokumente/Gemeindegrenzen.zip)


