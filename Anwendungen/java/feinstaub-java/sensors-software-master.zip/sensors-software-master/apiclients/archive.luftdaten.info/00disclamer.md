# Archive of luftdaten.info / api.dusti.xyz

## about

This archive consists of CSV dumps of all outdoor PPD42NS sensor that seem to have valid data.

## Problems

Please report problems in our opendata-stuttgart issuetracker: https://github.com/opendata-stuttgart/meta/issues

## Future improvements

- description of position of sensor on location
- image of sensor at location
