** Config script for dust sensor

Dependencies:

platform.io: compile and upload firmware

perl modules: Curses, Curses::UI
