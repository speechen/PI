# esp8266 with nodemcu

## Intro

Howto flash nodemcu on esp8266: http://blog.madflex.de/first-steps-with-the-esp8266/

## Getting this to work

Have a look into the [plugin framework](plugin_framework)

## Some Links

* pin layout: http://playground.boxtec.ch/doku.php/wireless/esp8266
* lua module reference: http://www.nodemcu.com/docs/
