## dht22-shack

temperature sensors for shackspace, powered over selfmade PoE

## dht22-wifi

## mma7455

working code for gravity sensor

## mqtt

## multisens

## pintester

## ppd42ns-wificonfig-ppd-sds-dht

maintained version, includes config over wifi, code for sensors ppd42ns, sds011, dht11/22, bmp160 and oled display

## restapi-test

## sensordev  

## setrgbledbyphoto  
  
## archive  
- i2scan (i2c scanner for esp8266)
- minimal (minimal arduino sketch)
- ppd42ns
- ppd42ns-wifi-dht
- ppd42ns-wifi-dht-mqtt

