
GPS NMEA Parser lib:
http://arduiniana.org/libraries/tinygpsplus/

ESP Software Serial (should be built in) 
https://github.com/plerup/espsoftwareserial

do not connect GPS to 3v3 of esp board, it might not be able to provide enough power,  use a DC-DC voltage regulator
