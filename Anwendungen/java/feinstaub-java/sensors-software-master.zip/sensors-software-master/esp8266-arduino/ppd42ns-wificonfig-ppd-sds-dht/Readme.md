 This source code was moved to https://github.com/opendata-stuttgart/sensors-software/tree/master/airrohr-firmware
