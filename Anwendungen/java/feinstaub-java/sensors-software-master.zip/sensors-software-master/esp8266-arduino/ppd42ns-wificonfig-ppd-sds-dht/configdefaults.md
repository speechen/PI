# Default configuration settings

* power the sensor (via USB)
* wait 20 seconds
* connect to Wireless Access Point with the name: Feinstaubsensor-<ID>
* browse to/open [http://192.168.4.1/](http://192.168.4.1/)
* "Configure wifi"

    <network list>
SSID
password
Senden an luftdaten.info (0/1) ?
Senden an madavi.de (0/1) ?
Seriell als CSV (0/1) ?
DHT Sensor (0/1) ?
PPD42NS Sensor (0/1) ?
SDS Sensor (0/1) ?
BMP Sensor (0/1) ?
Display (0/1) ?
Senden an eigene API (0/1)?

save

Scan
