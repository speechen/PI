# Diskussion notwendiger Features

2016-04-05


* OTA update: what about the SPIFF/Memory size? can SPIFF be reduced in favour of 
    * https://harizanov.com/2015/06/firmware-over-the-air-fota-for-esp8266-soc/

