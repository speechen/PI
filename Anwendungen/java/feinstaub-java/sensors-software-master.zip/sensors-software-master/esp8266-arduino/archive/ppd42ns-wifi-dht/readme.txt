


source of DHT.h and DHT.cpp: https://github.com/adafruit/DHT-sensor-library
