
currently working on plots from csv data, which can be fetched with this wget script: [../apiclients/getarchive.sh](../apiclients/getarchive.sh).

