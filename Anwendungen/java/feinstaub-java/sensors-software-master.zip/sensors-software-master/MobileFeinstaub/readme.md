# Mobile Feinstaub Messung

Source code für cordova (https://cordova.apache.org/)

benötigte Plugins

CordovArduino (cordova plugin add cordovarduino)
