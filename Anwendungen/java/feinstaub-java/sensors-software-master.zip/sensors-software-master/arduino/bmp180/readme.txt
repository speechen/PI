Library code from https://github.com/adafruit/Adafruit-BMP085-Library

