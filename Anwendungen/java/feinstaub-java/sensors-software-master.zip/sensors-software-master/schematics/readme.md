# Info

Software used: Fritzing

## Ubuntu

```sudo apt-get install fritzing```
