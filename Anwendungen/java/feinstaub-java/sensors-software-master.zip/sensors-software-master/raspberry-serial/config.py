# set SENSOR_UID to the UID of your sensor

settings = {}
settings['SENSOR_UID'] = 'FIXME'
settings['SENSOR_PPD42NS_UID'] = 'TEST'
settings['SENSOR_SHT10_UID'] = 'TEST2'
