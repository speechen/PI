sudo apt-get install -y python-scipy
