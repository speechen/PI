#include <string>
#include <aslam/calibration/model/Joint.h>

namespace aslam {
namespace calibration {

Joint::~Joint() {
}

} /* namespace calibration */
} /* namespace aslam */
