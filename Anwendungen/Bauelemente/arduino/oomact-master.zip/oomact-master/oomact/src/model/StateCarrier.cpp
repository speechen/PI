#include <aslam/calibration/calibrator/StateCarrier.h>

namespace aslam {
namespace calibration {

void aslam::calibration::StateCarrier::writeState(const CalibratorI& /*calib*/, const std::string& /*pathPrefix*/) const {
}

} /* namespace calibration */
} /* namespace aslam */
