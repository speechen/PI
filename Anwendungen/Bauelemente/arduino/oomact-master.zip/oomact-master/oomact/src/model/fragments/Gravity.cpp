#include <aslam/calibration/model/fragments/Gravity.h>

namespace aslam {
namespace calibration {

} /* namespace calibration */
} /* namespace aslam */
