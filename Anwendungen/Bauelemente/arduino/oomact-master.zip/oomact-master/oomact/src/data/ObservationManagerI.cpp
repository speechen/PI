#include <aslam/calibration/data/ObservationManagerI.h>

namespace aslam {
namespace calibration {

ObservationManagerI::ObservationManagerI() {
}

ObservationManagerI::~ObservationManagerI() {
}

} /* namespace calibration */
} /* namespace aslam */
