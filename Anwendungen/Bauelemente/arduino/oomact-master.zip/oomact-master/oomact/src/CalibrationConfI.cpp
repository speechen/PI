#include <aslam/calibration/calibrator/CalibrationConfI.h>

namespace aslam {
namespace calibration {

CalibrationConfI::~CalibrationConfI() {

}

} /* namespace calibration */
} /* namespace aslam */
