#include <aslam/calibration/input/InputProviderI.h>

namespace aslam {
namespace calibration {

InputProviderI::InputProviderI() {
}

InputProviderI::~InputProviderI() {
}

} /* namespace calibration */
} /* namespace aslam */
