#include <aslam/calibration/plan/Driver.h>

namespace aslam {
namespace calibration {
namespace plan {

Driver::Driver() {
}

Driver::~Driver() {
}

} /* namespace plan */
} /* namespace calibration */
} /* namespace aslam */
