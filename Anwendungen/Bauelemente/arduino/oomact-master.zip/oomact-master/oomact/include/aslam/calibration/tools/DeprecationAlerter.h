#ifndef H61102552_F2B3_4E09_AD6E_F774D85DED56
#define H61102552_F2B3_4E09_AD6E_F774D85DED56

#include <string>

namespace aslam {
namespace calibration {

void parameterDeprecationAlerter(std::string path, std::string hint);

} /* namespace calibration */
} /* namespace aslam */

#endif /* H61102552_F2B3_4E09_AD6E_F774D85DED56 */
