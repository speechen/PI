#ifndef H4CA2088F_E492_4165_B0A9_629F2929CA39
#define H4CA2088F_E492_4165_B0A9_629F2929CA39

#include <aslam/calibration/calibrator/StateCarrier.h>

namespace aslam {
namespace calibration {

class Joint : public StateCarrier {
 public:
  virtual ~Joint();
};

} /* namespace calibration */
} /* namespace aslam */

#endif /* H4CA2088F_E492_4165_B0A9_629F2929CA39 */
