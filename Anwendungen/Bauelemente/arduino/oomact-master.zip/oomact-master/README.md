Object Oriented Modular Abstract Calibration Toolbox (oomact)
===============

[![Build Status](http://129.132.38.183:8080/buildStatus/icon?job=oomact)](http://129.132.38.183:8080/job/oomact/)

Modular toolbox to build online / offline incremental / batch calibration modules.

## License
3-Clause BSD; see LICENSE

## Acknowledgments
This work is supported in part by the European Union's Seventh Framework Programme (FP7/2007-2013) under grant #610603 (EUROPA2).
