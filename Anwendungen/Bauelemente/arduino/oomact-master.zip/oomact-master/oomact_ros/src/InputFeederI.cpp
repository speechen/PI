#include "aslam/calibration/ros/InputFeederI.h"

namespace aslam {
namespace calibration {
namespace ros {

InputFeederI::InputFeederI() {
}

InputFeederI::~InputFeederI() {
}

} /* namespace ros */
} /* namespace calibration */
} /* namespace aslam */
