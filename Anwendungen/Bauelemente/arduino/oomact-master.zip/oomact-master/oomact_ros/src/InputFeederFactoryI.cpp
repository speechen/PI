#include "aslam/calibration/ros/InputFeederFactoryI.h"

namespace aslam {
namespace calibration {
namespace ros {

InputFeederFactoryI::InputFeederFactoryI() {
}

InputFeederFactoryI::~InputFeederFactoryI() {
}

} /* namespace ros */
} /* namespace calibration */
} /* namespace aslam */
